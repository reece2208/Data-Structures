GNDREE002

I have put all the relevent and completed java files under the 'src' folder in this directory
Run the 'UserInterface.java' file to check if it runs correctly.

.git repo (it may be hidden if you're using windows) is in current directly as it the JUnit test files
JaCaCo testing was not done as it was not listed as a requirement.

I was unable to complete the performance testing and load testing questions due to unforeseen circumstances.

The word documentation for the latter parts of the Assignment are in this (current) directory as I was still able to do this through research.
