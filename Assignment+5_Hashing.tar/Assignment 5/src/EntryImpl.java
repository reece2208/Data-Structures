
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Reece
 */
public class EntryImpl implements Entry{
     String word=null;
     List<Definition> definitions=new ArrayList<>();
    
     public EntryImpl(String word,Definition definition){
         this.word=word;
         definitions.add(definition);
     }
     
     
     @Override
    public String getWord() {
        return word;
    }

    @Override
    public List<Definition> getDefinitions() {
        return definitions;
    }

    @Override
    public void addDefinition(WordType wordType, String description) {
        definitions.add(new Definition(wordType,description)); 
    }

    @Override
    public void addDefinition(Definition definition) {
        definitions.add(definition); 
    }

    @Override
    public boolean isEntryFor(String word) {
        return this.word.equalsIgnoreCase(word);
    }
    
    public String toString(){
        String ts=word+": ";
        for (Definition def:definitions) {
            ts+=def.getDescription()+";";
        }
        return ts;
    }
    
}
