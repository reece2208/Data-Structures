
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class QPHashtable implements Dictionary {

    private final static int DEFAULT_SIZE = 50;

    private static Entry[] table;
    private int entries;
    int tableSize = DEFAULT_SIZE;

    public QPHashtable() {
        this(DEFAULT_SIZE);
    }

    public QPHashtable(int size) {
        this.table = new Entry[size];
        this.entries = 0;
        tableSize = size;
    }

    private int hashFunction(String key, int r) { //hash function from supplied example

        int hashValue = 0;
        int temp = 0;

        for (int i = 0; i < key.length(); i++) {
            /**
             * Convert string (key) into a natural number *
             */
            temp = (temp + (int) key.charAt(i));
        }
        /**
         * compute index in hash table *
         */
        hashValue = (temp + (r * r)) % table.length;
        return hashValue;

    }
        
    @Override
    public boolean containsWord(String word) {
        int probe = 0;
        int position = hashFunction(word, probe);//Uses hash function to check where word should be in table

        if (table[position] == null) {
            return false;
        } else if (table[position].isEntryFor(word)) {
            return true;
        } else {

            if (position == (table.length - 1)) {
                position = 0;
            } else {
                probe++;
                position = hashFunction(word, probe);
            }

            while ((position != -1)) {
                if (table[position] == null) {
                    return false;
                } else if (table[position].isEntryFor(word)) {
                    position = -1;
                    return true;
                } else {
                    if (position == (table.length - 1)) {
                        position = 0;
                    } else {
                        probe++;
                        position = hashFunction(word, probe); //recheck quadratically
                    }
                }
            }
        }
        return false;
    }

    @Override
    public List<Definition> getDefinitions(String word) { //method to get the definitons of the given word, searches quadratically
        int r = 0;
        int position = hashFunction(word, r);
        boolean done = false;

        if (table[position] == null) { //the definition does not exist
            return null;
        } else if (table[position].isEntryFor(word)) {
            return table[position].getDefinitions();    //returns definition if found
        } else {
            if (position == (table.length - 1)) {
                position = 0;
            } else {
                r++;
                position = hashFunction(word, r);
            }
            while (!done) {
                if (table[position] == null) {
                    return null;
                } else if (table[position].isEntryFor(word)) {
                    done = true;
                    return table[position].getDefinitions();
                } else {

                    if (position == (table.length - 1)) {
                        position = 0;
                    } else {
                        r++;
                        position = hashFunction(word, r); //probe 
                    }
                }
            }
        }

        return null;

    }

    @Override
    public void insert(String word, Definition definition) {    //method to insert quadratically

        int r = 0;
        int position = hashFunction(word, r);

        if (table[position] == null) {
            table[position] = new EntryImpl(word, definition);
            entries++;
        } else if (table[position].isEntryFor(word)) {

            table[position].addDefinition(definition);
        } else {
            if (position == (table.length - 1)) {   //look for next available space
                position = 0;
            } else {
                r++;
                position = hashFunction(word, r);
            }

            while ((position != -1)) {
                if (table[position] == null) {
                    table[position] = new EntryImpl(word, definition);
                    entries++;
                    position = -1;
                } else if (table[position].isEntryFor(word)) {
                    table[position].addDefinition(definition);
                    position = -1;
                } else {
                    if (position == (table.length - 1)) {
                        position = 0;
                    } else {
                        r++;
                        position = hashFunction(word, r);   //uses hash function to probe next space
                    }
                }
            }
        }
        //load factor does not need to be checked as values and table size are fixed
    }

    @Override
    public int size() {
        return this.entries;
    }

    public double loadFactor() {
        return entries / (double) table.length;
    }

    @Override
    public boolean isEmpty() {
        return entries == 0;
    }

    @Override
    public void empty() {
        this.table = new Entry[this.table.length];
        this.entries = 0;
    }



}
