
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class SCHashtable implements Dictionary{
     private final static int DEFAULT_SIZE = 50;

    private Entry[] table;
    private int entries;

    public SCHashtable() {
        this(DEFAULT_SIZE);
    }

    public SCHashtable(int size) {
        this.table = new Entry[size];
        this.entries = 0;
    }

    private int hashFunction(String key) {
        int hashValue = 0; //init hash value

        for (int i = 0; i < key.length(); i++) {
            hashValue = 37 * hashValue + key.charAt(i); //from textbook
        }

        hashValue %= table.length;
        if (hashValue < 0) {
            hashValue += table.length;
        }

        return hashValue;
    }

    public boolean containsWord(String word) {
        for (int i = hashFunction(word); i < table.length; i++) {//check from hash
            if (table[i].isEntryFor(word)) {
                return true;
            }
        }
        for (int j = 0; j < hashFunction(word); j++) {// check wrap around
            if (table[j].isEntryFor(word)) {
                return true;
            }
        }
        return false;
    }

    public List<Definition> getDefinitions(String word) {
        try{
        for (int i = hashFunction(word); i < table.length; i++) { //check from hash
            if (table[i].isEntryFor(word)) {
                return table[i].getDefinitions();
            }
        }
        for (int j = 0; j < hashFunction(word); j++) { // check wrap around
            if (table[j].isEntryFor(word)) {
                return table[j].getDefinitions();
            }
        }
        }catch(Exception e){
        
        }
        return null;
    }

    public void insert(String word, Definition definition) {
        for (int i = hashFunction(word); i < table.length; i++) {
            if (table[i] == null) {
             table[i]=new EntryImpl(word,definition);                
                return;
            }
            else if(word.equalsIgnoreCase(table[i].getWord())){ //case for if the same word is found
                table[i].addDefinition(definition);
            }
          //collision
        }
        for (int i = 0; i < hashFunction(word); i++) {
            if (table[i] == null) {
                table[i]=new EntryImpl(word,definition);

                return;
            }
            else if(word.equalsIgnoreCase(table[i].getWord())){
                table[i].addDefinition(definition);
            }
          //Collision
        }

    }

    public boolean isEmpty() {
        return entries == 0;
    }

    public void empty() {
        this.table = new Entry[this.table.length];
        this.entries = 0;
    }

    public int size() {
        return this.entries;
    }

    /* Hash Table Functions */
    /**
     * Obtain the current load factor (entries / table size).
     */
    public double loadFactor() {
        return entries / (double) table.length;
    }

    /* DEBUGGING CODE */
    /**
     * Print the contents of the given hashtable.
     */
    public static void debug_print(SCHashtable hashtable) {
        Entry[] table = hashtable.table;
        for (int i = 0; i < table.length; i++) {
            System.out.printf("\n%4d : %s", i, table[i]);
        }
    }

}
