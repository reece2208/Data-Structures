
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class MainClass {

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        Scanner scanner2 = new Scanner(System.in);
        SimpleBST tree = new SimpleBST();
        SimpleBST tree2 = new SimpleBST();
        try{
        PrintStream t1 = new PrintStream(new FileOutputStream(new File("T1.out")));
        PrintStream t2 = new PrintStream(new FileOutputStream(new File("T2.out")));
        
        System.out.print("Enter a comma separated list of numbers for tree one: ");
        scanner = new Scanner(scanner.nextLine()).useDelimiter("\\s*,\\s*");
        while (scanner.hasNextInt()) {
            tree.insert(scanner.nextInt());
        }
        scanner.close();
        System.out.print("Enter a comma separated list of numbers for tree two: ");
        scanner2 = new Scanner(scanner2.nextLine()).useDelimiter("\\s*,\\s*");
        while (scanner2.hasNextInt()) {
            tree2.insert(scanner2.nextInt());
        }
        scanner2.close();
        System.out.println("Tree One");
        SimpleBST.print(tree, new SimpleTreeWriterImpl(t1));
        System.out.println("\nTree Two");
        SimpleBST.print(tree, new SimpleTreeWriterImpl(t2));
        //System.out.println(tree.getLargest());

        if (tree.similar(tree2)) {
            System.out.println("\nThe trees are similar.");
        } else {
            System.out.println("\nThe trees are not similar.");
        }
        }catch(Exception e){
            
        }

    }
}
