
import java.io.PrintStream;
import java.util.ArrayList;
/**
 *
 * @author Reece
 */
class SimpleTreeWriterImpl implements SimpleTreeWriter {

    int height = 0;
    int level = 0; //initialise level to 0;
    String blanks = "";
    PrintStream out;

    public SimpleTreeWriterImpl(PrintStream out) {
        this.out=out;
    }

    @Override
    public void setDestination(PrintStream stream) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override//method that recives root node then prints out the tree using TreeUtils class to get node data
    public void write(BinaryTreeNode root) {
        ArrayList<BinaryTreeNode> lv;
        TreeUtils util = new TreeUtils();
        try{
        height = root.getHeight();
        for (int i = 0; i < root.getLargest().toString().length(); i++) {
            blanks += " ";
        }
        lv = util.zeroList(root);
        out.print(nStrings(blanks,LeadingBlanks(0)));
        out.printf("%" + blanks.length() + "d", root.getItem());
        lv = util.nList(lv);
        for (int i = 1; i < height ; i++) { //loops levels 
            out.println(nStrings(blanks, LeadingBlanks(i)));
            for (int j = 0; j < lv.size(); j++) {
                try {
                    out.printf("%" + blanks.length() + "d", lv.get(j).getItem());
                }catch(NullPointerException e){
                    out.print(blanks);
                }
                out.print(nStrings(blanks, NodesBlanks(i)));
            }
            lv = util.nList(lv);

        }
        }catch(NullPointerException e){
            
        }
    }

    //blanks before 1st node on level L
    public int LeadingBlanks(int l) {
        return (int) (((Math.pow(2, height - l) - 1) / 2));
    }

    //blanks between nodes on level L
    public int NodesBlanks(int l) {
        return (int) (((Math.pow(2, height - l) - 1)));
    }

    public String nStrings(String in, int n) { //repeats an inputted string n number of times
        String a=in;
        for (int i = 0; i < n; i++) {
            a=a+in;
        }
        
        return a;
    }

}
