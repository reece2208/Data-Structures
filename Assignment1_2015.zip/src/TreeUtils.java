
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Reece
 */
class TreeUtils {
    
    ArrayList lvl = new ArrayList();
    
    static boolean similar(BinaryTreeNode root, BinaryTreeNode root0) {
    // Empty trees are equal
    if (root == null && root0 == null){
        return true;}

    // Empty tree is not equal to a non-empty one
    if ((root == null &&  root0!= null)
        || (root != null && root0 == null)){
        return false;}

    // otherwise check recursively
    return similar(root.getRight(), root0.getLeft())
        && similar(root.getRight(), root0.getLeft());
    }
    //Method to return node list at lvl zero
    public ArrayList zeroList(BinaryTreeNode root){
        ArrayList rt = new ArrayList();
        
        try{rt.add(root);
        }catch(Exception e){
        }
        return rt;
    }
    
     public ArrayList nList(ArrayList<BinaryTreeNode> lvl){
           //print out list of nodes below parsed level
         ArrayList nlvl = new ArrayList();
         for (int i = 0; i < lvl.size(); i++) {
             try{
             nlvl.add(lvl.get(i).getLeft());
             }catch(Exception e){
             
             }
             try{
             nlvl.add(lvl.get(i).getRight());
             }catch(Exception e){
             }
         }
         
         

         return nlvl;
     }
      
}
