
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Utility procedures for binary tree structures.
 *
 * @author Stephan Jamieson
 * @version 25/2/2015
 */
public class TreeUtils {

    /**
     * Obtain the height value of the given node.
     *
     * @return 0 if <code>node==null</code>, otherwise
     * <code>node.getHeight()</code>.
     */
    public static int height(AVLTreeNode node) {
        if (node == null) {
            return 0;
        } else {
            return node.getHeight();
        }
    }

    /**
     * Determine whether the given tree structure contains the given key.
     */
    public static boolean contains(AVLTreeNode node, String key) {
        if (node == null) {
            return false;
        } else if (node.getStr().equalsIgnoreCase(key)) {
            return true;
        } else if (getUni(key) < node.getKey()) {
            return contains(node.getLeft(), key);
        } else {
            return contains(node.getRight(), key);
        }
    }
    
    //return alphabetic number value of 1st letter of input
    public static int getUni(String input){
        return (int)input.toUpperCase().charAt(0)-64;
    }

    /**
     * Recursive implementation of insert on an AVLTreeNode structure.
     */
    public static AVLTreeNode insert(AVLTreeNode node, String key) {
        // Your code here
        if (node == null) {
            //System.out.println("t");
            node = new AVLTreeNode(key);
        } else if (node.getKey()==getUni(key)) {
            node.setStr(key);
            //Replace (Dupl. Key)
        } else if (getUni(key) < node.getKey()) {
            node.setLeft(insert(node.getLeft(), key));
            if (Math.abs(node.getBalanceFactor()) > 1) {
                node = rebalanceLeft(node, key); //Insert method used rotation methods through rebalance left and right classes
            }
        } else {
            node.setRight(insert(node.getRight(), key));
            if (Math.abs(node.getBalanceFactor()) > 1) {
                node = rebalanceRight(node, key); //Insert method used rotation methods through rebalance left and right classes
            }
        }
//        if(node.getLeft().getHeight()>=node.getRight().getHeight()){
//            node.setHeight(node.getLeft().getHeight()+1);
//        }
//        else{
//            node.setHeight(node.getRight().getHeight()+1);
//        }
//        if (node.hasLeft() && node.hasRight()) {
//            node.setHeight(max(node.getLeft().getHeight(), node.getRight().getHeight()) + 1);
//        } else if (node.hasLeft()) {
//            node.setHeight(node.getLeft().getHeight() + 1);
//        } else if (node.hasRight()) {
//            node.setHeight(node.getRight().getHeight() + 1);
//        }else{
//            node.setHeight(1);
//        }
        node.setHeight(Height(node));

        return node;
    }

    /**
     * Return
     * maxinode.setHeight(max(node.getLeft().getHeight(),node.getRight().getHeight())+1);mum
     * of lhs and rhs.
     */
    private static int max(int lhs, int rhs) {
        //return lhs > rhs ? lhs : rhs;
        if (lhs > rhs) {
            return lhs;
        } else {
            return rhs;
        }
    }

    /**
     * Rotate binary tree node with left child. This is a single rotation for
     * case 1.
     */
    public static AVLTreeNode rotateWithLeftChild(AVLTreeNode k2) {
        AVLTreeNode k1 = k2.getLeft();
        k2.setLeft(k1.getRight());
        k1.setRight(k2);
        //Update heights
//        k2.setHeight(max(k2.getLeft().getHeight(), k2.getRight().getHeight()) + 1);
//        k1.setHeight(max(k1.getLeft().getHeight(), k2.getHeight()) + 1);
        k2.setHeight(Height(k2));
        k1.setHeight(Height(k1));
        return k1;
    }

    /**
     * Rotate binary tree node with right child. This is a single rotation for
     * case 4.
     */
    public static AVLTreeNode rotateWithRightChild(AVLTreeNode k1) {
        AVLTreeNode k2 = k1.getRight();
        k1.setRight(k1.getLeft());
        k2.setLeft(k1);
        //Update heights
//        k1.setHeight(max(k1.getLeft().getHeight(), k1.getRight().getHeight()) + 1);
//        k2.setHeight(max(k2.getRight().getHeight(), k1.getHeight()) + 1);
        k1.setHeight(Height(k1));
        k2.setHeight(Height(k2));
        return k2;
    }

    /**
     * Double rotate binary tree node: first rotate k3's left child with its
     * right child; then rotate node k3 with the new left child. This is a
     * double rotation for case 2.
     */
    public static AVLTreeNode doubleRotateWithLeftChild(AVLTreeNode k3) {
        k3.setLeft(rotateWithRightChild(k3.getLeft()));
        return rotateWithLeftChild(k3);
    }

    /**
     * Double rotate binary tree node: first rotate k1's right child with its
     * left child; then rotate node k1 with the new right child. This is a
     * double rotation for case 3.
     */
    public static AVLTreeNode doubleRotateWithRightChild(AVLTreeNode k1) {
        k1.setRight(rotateWithLeftChild(k1.getRight()));
        return rotateWithRightChild(k1);
    }

    /**
     * Obtain a list containing the root node of the given structure i.e. tNode
     * itself.
     */
    public static List<AVLTreeNode> levelZero(AVLTreeNode tNode) {
        List<AVLTreeNode> level = new ArrayList<AVLTreeNode>();
        level.add(tNode);
        return level;
    }

    /**
     * Given a list of nodes, obtain the next level.
     *
     * <p>
     * If the tree structure is incomplete, <code>AVLTreeNode.EMPTY_NODE</code>
     * is inserted as a place holder for each missing node.
     * </p>
     */
    public static List<AVLTreeNode> nextLevel(List<AVLTreeNode> level) {
        List<AVLTreeNode> nextLevel = new ArrayList<AVLTreeNode>();

        for (AVLTreeNode node : level) {
            nextLevel.add(node.hasLeft() ? node.getLeft() : AVLTreeNode.EMPTY_NODE);
            nextLevel.add(node.hasRight() ? node.getRight() : AVLTreeNode.EMPTY_NODE);
        }
        return nextLevel;
    }

    /**
     * Determine whether node is a place holder i.e.
     * <code>node==AVLTreeNode.EMPTY_NODE</code>
     */
    public static boolean isPlaceHolder(AVLTreeNode node) {
        return node == AVLTreeNode.EMPTY_NODE;
    }

    //methods both to rebalance right tree
    private static AVLTreeNode rebalanceRight(AVLTreeNode node, String key) {
        if (getUni(key) > node.getRight().getKey()) {
            //Case 3 applies
            return rotateWithRightChild(node);
        } else {
            //Case 4 applies
            return doubleRotateWithRightChild(node);
        }
    }

    //methods both to rebalance left tree
    private static AVLTreeNode rebalanceLeft(AVLTreeNode node, String key) {
        if (getUni(key) < node.getLeft().getKey()) {
            //Case 1 applies
            return rotateWithLeftChild(node);
        } else {
            //Case 2 applies
            return doubleRotateWithLeftChild(node);
        }
    }
    
    /**
     * Obtain the height of this tree structure.
     */
    public static Integer Height(AVLTreeNode node) {
        if (node.hasLeft() && node.hasRight()) {
            return Math.max(node.getLeft().getHeight(), node.getRight().getHeight())+1;
        }
        else if (node.hasLeft()) {
            return node.getLeft().getHeight()+1;
        }
        else if (node.hasRight()) {
            return node.getRight().getHeight()+1;
        }
        else {
            return 1;
        }
    }
}
