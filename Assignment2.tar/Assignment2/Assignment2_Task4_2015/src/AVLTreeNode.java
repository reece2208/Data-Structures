
import java.util.ArrayList;


/**
 * Implements a node suitable for building AVL tree structures.
 *
 * @author Stephan Jamieson
 * @version 3/3/2015
 */
public class AVLTreeNode {

    private Integer key;
    private int height;
    private ArrayList<String> str;

    private AVLTreeNode left;
    private AVLTreeNode right;
    //private AVLTreeNode parent;

    public final static AVLTreeNode EMPTY_NODE = new AVLTreeNode();

    private AVLTreeNode() {
        this.key = null;
        this.height = -1;
        this.left = null;
        this.right = null;
        this.str=null;
    }
    
    /**
     * Create an AVLTreeNode that contains the given key
     * @param str
     */
    public AVLTreeNode(String str) {
        this(null, str, null);
        key = TreeUtils.getUni(str);
        
    }

    AVLTreeNode(AVLTreeNode left, String str, AVLTreeNode right) {
        assert (str != null);
        this.left = left;       
        this.right = right;       
        this.key = TreeUtils.getUni(str);
        this.height = 0;
        this.str=new ArrayList();
        this.str.add(str);
    }

    /* Low level structural operations */
    /**
     * Determine whether this node has a left branch.
     */
    public boolean hasLeft() {
        return left != null;
    }

    /**
     * Determine whether this node has a right branch.
     */
    public boolean hasRight() {
        return right != null;
    }

    /**
     * Determine whether this node has a key.
     */
    public boolean hasKey() {
        return key != null;
    }
    
    public boolean hasStr(){
        return str!=null;  
    }

    /**
     * Obtain the key stored in this node.
     * @return key
     */
    public Integer getKey() {
        return key;
    }

    /**
     * Obtain the height value stored at this node. (Requirs that ka
     * @return 
     */
    public int getHeight() {
        return this.height;
    }

    /**
     * Obtain the balance factor for this node.
     * @return 
     */
    public int getBalanceFactor() {
        int left = (this.hasLeft() ? this.getLeft().getHeight() : 0);
        int right = (this.hasRight() ? this.getRight().getHeight() : 0);
        return left - right;
    }

    /**
     * Obtain this node's left branch. Requires that
     * <code>this.hasLeft()</code>.
     */
    public AVLTreeNode getLeft() {
        return this.left;
    }

    /**
     * Obtain this node's right branch. Requires that
     * <code>this.hasRight()</code>.
     */
    public AVLTreeNode getRight() {
        return this.right;
    }

    /**
     * Set the height stored in this node.
     */
    public void setHeight(int height) {
        assert (this != EMPTY_NODE);
        this.height = height;
    }

    /**
     * Set this node's left branch.
     */
    public void setLeft(AVLTreeNode tree) {
        assert (this != EMPTY_NODE);
        this.left = tree;
    }

    /**
     * Set this node's right branch.
     */
    public void setRight(AVLTreeNode tree) {
        assert (this != EMPTY_NODE);
        this.right = tree;
    }

    /**
     * Obtain the longest node label for nodes stored in this tree structure.
     */
    public Integer getLargest() {
        Integer largest = this.toString().length();
        if (this.hasLeft()) {
            largest = Math.max(largest, this.getLeft().getLargest());
        }
        if (this.hasRight()) {
            largest = Math.max(largest, this.getRight().getLargest());
        }
        
        return largest;
    }

    /**
     * Obtain a String representation of this node.
     */
    public String toString() {
        String list="";
        ArrayList<String> used=new ArrayList(); //store previous value on list
        used.add("");
        try{
        for(int i=0;i<str.size();i++){ 
            if(used.indexOf(str.get(i))<0){ //Dont add duplicates to string
                used.add(str.get(i));
                list+="\n"+str.get(i);
            }
           
        }
        return   "(" + this.str.get(0).toUpperCase().charAt(0) + ")"+"("+str.size()+")"+list;
        }catch(NullPointerException e){
            
        }
        return "";
    }
    
        public String toStringh() {//horizontal toString
        String list="";
        ArrayList<String> used=new ArrayList(); //store previous value on list
        used.add("");
        for(int i=0;i<str.size();i++){ 
            if(used.indexOf(str.get(i))<0){ //Dont add duplicates to string
                used.add(str.get(i));
                list+=str.get(i)+", ";
            }
        }  
        return   "("+str.size()+")("+list.substring(0, list.length()-2)+")";
    }
//adds string to the list in node
    void addStr(String small) {
        str.add(small);
        key = TreeUtils.getUni(small);
    }
//Deletes item from list is item is in list
    public void listDelete(String strdel){
        if(str.contains(strdel)){
            str.remove(strdel);
        }
    }
    
    public ArrayList<String> getStr(){
        return str;
    }
    
    public void setList(ArrayList list){
        this.str=list;
    }

}
