The Java files for each task are contained in the src folder for each of these directories.

There are makefiles in each src directory for the code.


