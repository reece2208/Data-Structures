Assignment done by:
	Reece Gounden GNDREE002
	Dhriven Hamlall	HMLDHR001
	
-Implementations of the naive and more efficient solutions can be found in the source folder along with the given sample data in the correct format.
-.git repo and testing files included in current folder.
-Report on the travelling salesman problem included in current folder in .pdf format

Assumptions:
	-Every node can go to every other node (As defined in the problem statement)
	-Distance between two cities cannot be a negative value (Distance is a scalar quantity)
