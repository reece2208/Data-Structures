
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * More efficient implementation of the traveling salesman problem
 *
 * @author Reece
 */
public class Efficient {

    static HashMap linklen = new HashMap();//holds vertex length for each connection
    static int nodenum = 0;//number of nodes
    static String nodestr = ""; //String where each char is a node
    static ArrayList<String> perms = new ArrayList();//Array holding String of each permutation
    static HashMap permcost = new HashMap(); //Maps permutation and its cost

    public static void main(String[] args) {
        long timestart = System.currentTimeMillis();
        int cost = 0;
        int cnt = 0;
        int min = 0; //hold most minimun permutation cost so far

        read(); //reads data from the text file        
        permutation(nodestr);
        int[] pathcost = new int[perms.size()]; /* array containing path lengths as its 
         easier to use arrays to output minimum value
         */

        String temp2;

        for (String permutation : perms) {
            String temporig = permutation; //store temp before its changed
            while (permutation.length() > 1) {
                try {
                    temp2 = permutation.charAt(0) + ":" + permutation.charAt(1);
                    cost += (int) linklen.get(temp2);
                    if (cost > min && cnt != 0) { //condition that wont allow cost calculation to continue if the cost has become greater than the already minimum cost 
                        cost = -1;
                        break;
                    }
                } catch (NullPointerException e) { /* Exception to check reverse order if
                                                    * value not found on map i.e "A E" -> "E A"    
                                                    */
                    
                    temp2 = permutation.charAt(1) + ":" + permutation.charAt(0);
                    cost += (int) linklen.get(temp2);
                    if (cost > min && cnt != 0) { 
                        cost = -1;
                        break;
                    }
                }
                permutation = permutation.substring(1);
            }
            if (cost > -1) { //Sets minimum and wont add the current 
                min = cost;
                pathcost[cnt] = cost;
                permcost.put(cost, temporig);
            }
            cost = 0;
            cnt++;
        }

        Arrays.sort(pathcost); //sorts using O(nlog(n)) performance faster than iterative search for min
        long timeend = System.currentTimeMillis();

        System.out.println("Shortest path is: " + permcost.get(min) + " (Or reverse)\n"
                + "Path length is: " + min + "\nElapsed Time in ms is: " + (timeend - timestart));

    }

    public static void read() {
        try {
            Scanner data = new Scanner(new FileReader("sample.txt"));
            String temp;
            while (data.hasNextLine()) {
                temp = data.nextLine();

                //maps a link between nodes 
                linklen.put(temp.substring(0, temp.lastIndexOf(":")), Integer.parseInt(temp.substring(temp.lastIndexOf(":") + 1)));

                //create string containing all node letters except A
                if (!nodestr.contains(temp.charAt(0) + "") && temp.charAt(0) != 'A') { //check first letter each line and wont add if theres repitition
                    nodestr += temp.charAt(0);
                }
                if (!nodestr.contains(temp.charAt(2) + "") && temp.charAt(2) != 'A') { //check second letter each line and wont add if theres repitition
                    nodestr += temp.charAt(2);
                }

            }
            //gets the number of nodes 
            nodenum = nodestr.length();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Naive.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static public void permutation(String str) {
        permutation("", str);
    }

    //method to recurively get each permutation of nodestr and store it with A as start point and end point
    private static void permutation(String prefix, String str) {
        int n = str.length();
        if (n == 0) {
            //System.out.println(prefix);
            perms.add("A" + prefix + "A"); //add each permutation to an arraylist 
        } else {
            for (int i = 0; i < n; i++) {
                permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i + 1, n));
            }
        }
    }
}
